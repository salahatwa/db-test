package com.nut.api._Private;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.nut.response.Response;
import com.nut.user.User;
import com.nut.user.UserDTO;
import com.nut.user.UserDTOupdate;
import com.nut.user.UserService;
import com.nut.user.role.Role;

import lombok.AllArgsConstructor;
import lombok.Data;



@AllArgsConstructor
@RestController
@RequestMapping("/v1/private")
public class UserController {
    private final UserService userService;

    private final ModelMapper modelMapper;

    // HEAD endpoint
    @GetMapping("/email/{userEmail}/check")
    public ArrayList<String> checkEmailAlreadyTaken(@PathVariable("userEmail") String userEmail){
        return userService.isNotEmailTaken(userEmail);
    }

    @GetMapping("/users")
    public ResponseEntity<Response<List<User>>> getUsers() {

        Response<List<User>> response = new Response<>();

        response.setData(userService.getUsers());

        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/user/id/{userId}")
    public ResponseEntity<Response<User>> getOneUserById(@PathVariable("userId") Long userId) {

        Response<User> response = new Response<>();

        response.setData(userService.getUserById(userId));

        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/user/username/{email}/{id}")
    public ResponseEntity<Response<User>> getOneUserByUsernameAndId(@PathVariable("email") String email,
                                                                    @PathVariable("id") Long id) {

        Response<User> response = new Response<>();

        User user = userService.getUserByEmailAndId(email,id);

        response.setData(user);

        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/user/username/{email}")
    public ResponseEntity<Response<User>> getOneUserByUsername(@PathVariable("email") String email) {

        Response<User> response = new Response<>();

        User user = userService.getUserByEmail(email);

        response.setData(user);

        return ResponseEntity.ok().body(response);
    }

    // TODO: disable in production
    @PostMapping("/user/save")
    public ResponseEntity<Response<UserDTO>> saveUser(@Valid @RequestBody UserDTO userDTO, BindingResult result) {

        Response<UserDTO> response = new Response<>();

        if (result.hasErrors()){
            result.getAllErrors().forEach( e -> response.getErrors().add(e.getDefaultMessage()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        User user = userService.saveUser(toEntity(userDTO));

        response.setData(toDto(user));

        URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/v1/private/user/save").toUriString());


        return ResponseEntity.created(uri).body(response);
    }

    @PostMapping("/create/user")
    public ResponseEntity<Response<UserDTO>> createUser(@Valid @RequestBody UserDTO userDTO, BindingResult result) {

        Response<UserDTO> response = new Response<>();

        if (result.hasErrors()){
            result.getAllErrors().forEach( e -> response.getErrors().add(e.getDefaultMessage()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        User user = userService.saveUser(toEntity(userDTO));

        response.setData(toDto(user));

        URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/v1/private/create/user").toUriString());

        return ResponseEntity.created(uri).body(response);
    }

    @PutMapping("/update/user/{userId}")
    public ResponseEntity<Response<User>> updateUser(
            @PathVariable("userId") Long userId,
            @RequestBody UserDTOupdate userDTOupdate, BindingResult result) {

        Response<User> response = new Response<>();

        if (result.hasErrors()){
            result.getAllErrors().forEach( e -> response.getErrors().add(e.getDefaultMessage()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        User user = userService.getUserById(userId);

        userDTOupdate.setId(userId);
        userDTOupdate.setEmail(user.getEmail());
        userDTOupdate.setPassword(user.getPassword());

        User userUpdated = userService.saveUser(toEntity(userDTOupdate));

        response.setData(userUpdated);

        return ResponseEntity.accepted().body(response);
    }

    @PostMapping("/role/save")
    public ResponseEntity<Response<Role>> saveRole(@RequestBody Role role, BindingResult result) {

        Response<Role> response = new Response<>();

        if (result.hasErrors()){
            result.getAllErrors().forEach( e -> response.getErrors().add(e.getDefaultMessage()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        response.setData(userService.saveRole(role));

        URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/v1/private/role/save").toUriString());

        return ResponseEntity.created(uri).body(response);
    }

    @PostMapping("/role/attach")
    public ResponseEntity<?> addRoleToUser(@RequestBody RoleToUserForm form, BindingResult result) {

        Response<?> response = new Response<>();

        if (result.hasErrors()){
            result.getAllErrors().forEach( e -> response.getErrors().add(e.getDefaultMessage()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        userService.addRoleToUser(form.getEmail(), form.getRoleName()) ;

        return ResponseEntity.ok().body(response.getErrors());
    }
    private UserDTO toDto(User user){
        return modelMapper.map(user, UserDTO.class);
    }
    private UserDTOupdate toDtoUpdate(User user){
        return modelMapper.map(user, UserDTOupdate.class);
    }
    private User toEntity(UserDTO userDTO){
        return modelMapper.map(userDTO, User.class);
    }private User toEntity(UserDTOupdate userDTO){
        return modelMapper.map(userDTO, User.class);
    }

}

@Data
class RoleToUserForm{
    private String email;
    private String roleName;
}
