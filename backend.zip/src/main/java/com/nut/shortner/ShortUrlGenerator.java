package com.nut.shortner;

import com.google.common.hash.Hashing;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;

/**
 * Generate shortened URL from oroginal long URL.
 */
public class ShortUrlGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(ShortUrlGenerator.class);

    static public String shortenUrl(String longUrl){
        LOGGER.debug("Generating short version of url:  " + longUrl);
        return Hashing.murmur3_32().hashString(longUrl, StandardCharsets.UTF_8).toString();
    }
}