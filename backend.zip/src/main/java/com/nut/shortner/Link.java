package com.nut.shortner;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@Entity
@ToString
@Table(name = "nt_link", uniqueConstraints = {
		@UniqueConstraint(name = "name_longurl_unique", columnNames = "longurl") })

//@JsonIgnoreProperties(value = { "createdAt", "updateAt" }, allowGetters = true)
public class Link {

	@Id
	@SequenceGenerator(name = "link_sequence", sequenceName = "link_sequence", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "link_sequence")
	@Column(name = "id", nullable = false)
	private Long id;

//    @Value("${app.domain}")
	private String domain;

	@NotBlank
	private String longurl;

	private String shorturl;

	private String shortperfix;

	private LinkStatus status = LinkStatus.DRAFT;

	@Column(nullable = false, updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	private Date createdAt;

	@Column(nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	private Date updatedAt;

	public Link(String longurl, String shorturl) {
		super();
		this.longurl = longurl;
		this.shorturl = shorturl;
		this.createdAt=new Date();
		this.updatedAt=new Date();
	}

}
