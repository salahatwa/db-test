package com.nut.shortner;


public enum LinkStatus {
	
	PUBLISHED("PUBLISHED", 0), DRAFT("DRAFT", 1), EXPIRED("EXPIRED", 2);

    private String name;
    private final int cod;

    private LinkStatus(String name, int cod){
        this.name = name;
        this.cod = cod;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCod() {
        return cod;
    }
}