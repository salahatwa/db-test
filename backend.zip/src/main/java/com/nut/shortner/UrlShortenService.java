package com.nut.shortner;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.nut.exceptions.InvalidShortUrlException;
import com.nut.exceptions.UrlAlreadyAddedException;

/**
 * URL service
 */
@Service
public class UrlShortenService {
	private static final Logger LOGGER = LoggerFactory.getLogger(UrlShortenService.class);

	@Value("${app.domain}")
	private String domain;

	@Autowired
	LinkRepository linkRepository;

	/**
	 *
	 * @param longUrl
	 * @return
	 * @throws UrlAlreadyAddedException
	 */
	public Link generateShortUrl(LinkRqDto linkRQ) throws UrlAlreadyAddedException {

		LOGGER.info("UrlShortenService : ",linkRQ);
		Optional<Link> url = linkRepository.findByLongurl(linkRQ.getUrl());

		if (url.isPresent()) {
			LOGGER.error("URL already added to database : " + linkRQ.getUrl());
			throw new UrlAlreadyAddedException(linkRQ.getUrl());
		}

		String linkDomain = Objects.nonNull(linkRQ.getDomain()) ? linkRQ.getDomain() : domain;

		String shortnerPrefix = ShortUrlGenerator.shortenUrl(linkRQ.getUrl());

		StringBuilder sb = new StringBuilder(linkDomain);
		sb.append(shortnerPrefix);
		Link custLink = new Link(linkRQ.getUrl(), sb.toString());

		custLink.setDomain(linkDomain);
		custLink.setShortperfix(shortnerPrefix);

		Link link = linkRepository.save(custLink);

		return link;
	}

	/**
	 * Given a short URL, return a previously persisted LongURL
	 * 
	 * @param shortUrl
	 * @return String
	 */
	public String redirect(String perfix) throws InvalidShortUrlException {
		Link url = linkRepository.findByShortperfix(perfix).orElseThrow(() -> new InvalidShortUrlException(perfix));
		return url.getLongurl();
	}

	/**
	 * List all currently persisted URLs
	 * 
	 * @return
	 * @throws InvalidShortUrlException
	 */
	public List<Link> listAll() {
		return linkRepository.findAll();
	}

}
