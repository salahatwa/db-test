package com.nut.signup;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;


@Getter
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class SignUpRequest {
	private final String alias;
	private final String cpf;
	private final String phoneNumber;
	private final Long income;
	private final String name;
	private final String email;
	private final String password;
}
