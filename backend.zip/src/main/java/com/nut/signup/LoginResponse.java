package com.nut.signup;

import org.springframework.security.core.userdetails.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class LoginResponse {
	private User user;
	private String accessToken;
	private String refreshToken;
}
