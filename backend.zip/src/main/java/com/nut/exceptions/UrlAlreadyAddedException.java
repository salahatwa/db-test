package com.nut.exceptions;

/**
 * Specific exception catering for when a long URL has already been submitted &
 * persisted.
 */
public class UrlAlreadyAddedException extends Throwable {

	public UrlAlreadyAddedException(String longUrl) {
		super("Url has already been added :" + longUrl);
	}
}