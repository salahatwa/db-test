package com.nut.exceptions;

/**
 * Specific exception catering for when a short URL is queried.
 */
public class InvalidShortUrlException extends Throwable {

	public InvalidShortUrlException(String shortUrl) {
		super("Could not find Short url :" + shortUrl);
	}
}