package com.nut.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.RedirectView;

import com.nut.service.InvalidShortUrlException;
import com.nut.service.UrlShortenService;

@Controller
@RequestMapping
public class RedirectController {

	@Autowired
	UrlShortenService urlShortenService;

	@RequestMapping("/{shorturl}")
	public RedirectView redirect(@PathVariable(value = "shorturl") String shorturl) throws InvalidShortUrlException {

		return new RedirectView(urlShortenService.redirect(shorturl));
	}
}
