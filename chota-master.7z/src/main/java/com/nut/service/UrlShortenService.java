package com.nut.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * URL service
 */
@Service
public class UrlShortenService {

	@Autowired
	LinkRepository linkRepository;

	/**
	 * Given a short URL, return a previously persisted LongURL
	 * 
	 * @param shortUrl
	 * @return String
	 */
	public String redirect(String perfix) throws InvalidShortUrlException {
		Link url = linkRepository.findByShortperfix(perfix).orElseThrow(() -> new InvalidShortUrlException(perfix));
		return url.getLongurl();
	}

	/**
	 * List all currently persisted URLs
	 * 
	 * @return
	 * @throws InvalidShortUrlException
	 */
	public List<Link> listAll() {
		return linkRepository.findAll();
	}

}
