# chota
URL Shortner

[![cliffton](https://circleci.com/gh/cliffton/chota.svg?style=svg&circle-token=8b9d431d354b832df798e1feb06aabce90496fd9)](https://circleci.com/gh/cliffton/chota.svg?style=svg&circle-token=8b9d431d354b832df798e1feb06aabce90496fd9)


Simple URL Shortner built using Spring Boot.   
**Does not scan all the urls when conversion from shortened url to long url instead uses base convertion to find the primary key**

## http://chota.cliffton.io


## Please set
- export CHOTA_DB_USER=whateverisname   
- export CHOTA_DB_PASSWORD=whateverispassword   

