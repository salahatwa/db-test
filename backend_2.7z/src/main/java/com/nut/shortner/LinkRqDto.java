package com.nut.shortner;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.URL;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LinkRqDto {
	@Size(max = 50, message = "Custom default domain")
	private String domain;

	@URL(message = "Invalid URL")
	@Size(min = 5, max = 900, message = "Long URL")
	@NotBlank(message = "URL Cannot be empty")
	private String url;
}
