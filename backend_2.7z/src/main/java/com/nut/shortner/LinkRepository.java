package com.nut.shortner;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface LinkRepository extends JpaRepository<Link, Long> {

	/**
	 *
	 * @param longUrl
	 * @param shortUrl
	 * @return
	 */
	List<Link> findByShorturlAndLongurl(String longUrl, String shorturl);

	/**
	 *
	 * @param shortUrl
	 * @return
	 */
	Optional<Link> findByShorturl(String shorturl);

	/**
	 *
	 * @param shortperfix
	 * @return
	 */
	Optional<Link> findByShortperfix(String shortperfix);

	/**
	 *
	 * @param longUrl
	 * @return
	 */
	Optional<Link> findByLongurl(String longurl);

	@Transactional
	@Modifying
	@Query("UPDATE Link l " + "SET l.status = ?2 " + "WHERE l.id = ?1")
	int updateLinkStatus(String id, LinkStatus status);

}
