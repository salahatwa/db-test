package com.nut.api._Public;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nut.exceptions.UrlAlreadyAddedException;
import com.nut.shortner.Link;
import com.nut.shortner.LinkRqDto;
import com.nut.shortner.UrlShortenService;

@RestController
@RequestMapping("/api")
public class LinkController {

	@Autowired
	UrlShortenService urlShortenService;

	@PostMapping("/link")
	public ResponseEntity<Link> createLink(@Valid @RequestBody LinkRqDto linkRQ) throws UrlAlreadyAddedException {
//        String alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
//        linkRepository.save(link);
//        long linkId = link.getId();
//        long remainder = 0;
//        long base = alpha.length();
//        ArrayList<Integer> digits = new ArrayList<>();
//        while (linkId > 0) {
//            remainder = linkId % base;
//            digits.add((int) remainder);
//            linkId = linkId / base;
//        }
//
//        String shorturl = "";
//        for (int i = digits.size() - 1; i >= 0; i--) {
//            shorturl += alpha.charAt(digits.get(i));
//        }
//
//        link.setShorturl(shorturl);
//        linkRepository.save(link);
//        link.setShorturl(domain + "r/" + shorturl);
		Link link = urlShortenService.generateShortUrl(linkRQ);
		return ResponseEntity.ok(link);
	}
}
