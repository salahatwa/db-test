package com.nut.user;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import com.nut.user.role.Role;

import java.util.ArrayList;
import java.util.Collection;



@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserDTOupdate {

    private Long id;

    private String alias;

    private String name;

    private String email;

    private Boolean locked = false;

    private Boolean enabled = false;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;

    private Collection<Role> roles = new ArrayList<>();

}
